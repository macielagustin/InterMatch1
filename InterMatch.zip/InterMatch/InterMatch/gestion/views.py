from django.shortcuts import render


def inicio(request):
    return render(request, 'gestion/inicio.html')

def registro(request):
    return render(request, 'gestion/registro.html')

def login(request):
    return render(request, 'gestion/login.html')

def registro_empresa(request):
    return render(request, 'gestion/registro_empresa.html') 

def registro_importador(request):
    return render(request, 'gestion/registro_importador.html') 

def base_admin(request):
    return render(request, 'gestion/base_admin.html')

def panel_admin(request):
    return render(request, 'gestion/panel_admin.html')

def gestionar_usuarios(request):
    return render(request, 'gestionar_usuarios.html')

def gestionar_reuniones(request):
    return render(request, 'gestionar_reuniones.html')

def definir_periodo(request):
    return render(request, 'definir_periodo.html')
