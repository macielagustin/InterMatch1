from django.urls import path
from . import views
from django.contrib.auth.views import LogoutView

urlpatterns = [
    path('', views.inicio, name='inicio'),
    path('registro/', views.registro, name='registro'),
    path('login/', views.login , name='login'),
    path('registro_empresa/', views.registro_empresa , name='registro_empresa'),
    path('registro_importador/', views.registro_importador, name='registro_importador'),
    
    
    
    #Panel de Administrador
    path('panel_admin/', views.panel_admin, name='panel_admin'),
    path('gestionar_usuarios/', views.gestionar_usuarios, name='gestionar_usuarios'),
    path('gestionar_reuniones/', views.gestionar_reuniones, name='gestionar_reuniones'),
    path('definir_periodo/', views.definir_periodo, name='definir_periodo'),
    path('base_admin/', views.base_admin, name='base_admin'),
    path('logout/', LogoutView.as_view(next_page='login'), name='cerrar_sesion'),
    path('definir_inscripcion/', views.definir_periodo, name='definir_inscripcion'),

]
